package com.lazday.news.ui.news

data class CategoryModel (
        val id: String,
        val name: String,
)
